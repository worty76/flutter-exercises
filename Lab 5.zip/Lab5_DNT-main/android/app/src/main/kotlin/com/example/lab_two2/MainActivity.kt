package com.example.lab_two2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
